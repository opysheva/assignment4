import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var temp: UILabel!
    static let identifier = String(describing: TableViewCell.self)

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
